var searchData=
[
  ['the_20ansi_2dproject_20for_20_3cem_3epython_3c_2fem_3e_0',['The ANSI-Project for &lt;em&gt;Python&lt;/em&gt;',['../index.html',1,'']]]
];

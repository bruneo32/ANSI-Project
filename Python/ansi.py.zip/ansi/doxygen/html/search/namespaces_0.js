var searchData=
[
  ['ansi_0',['ansi',['../namespaceansi.html',1,'']]]
];

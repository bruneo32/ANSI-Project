var searchData=
[
  ['bk_5frgb_0',['BK_RGB',['../namespaceansi.html#a86c3ccd4ca6c9df8e0407d52a18f1ed5',1,'ansi']]]
];

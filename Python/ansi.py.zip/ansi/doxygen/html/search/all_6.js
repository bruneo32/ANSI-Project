var searchData=
[
  ['faint_0',['FAINT',['../namespaceansi.html#a56870877a9fb805af40ed576c9a8dce2',1,'ansi']]],
  ['franktur_1',['Franktur',['../namespaceansi.html#a0dcfbb6282671398f9fe23fffb09c0e4',1,'ansi']]]
];

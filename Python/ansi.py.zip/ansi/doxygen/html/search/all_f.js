var searchData=
[
  ['under_0',['UNDER',['../namespaceansi.html#a5c480b9f96d43becafbe99fb9d9ca851',1,'ansi']]],
  ['under_5foff_1',['UNDER_OFF',['../namespaceansi.html#a5276114be066633844835ac7649540a3',1,'ansi']]]
];

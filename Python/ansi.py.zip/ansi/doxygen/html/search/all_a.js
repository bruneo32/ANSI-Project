var searchData=
[
  ['osc_0',['OSC',['../namespaceansi.html#aff36c662a848fbeb4d53923a372dbb8a',1,'ansi']]]
];

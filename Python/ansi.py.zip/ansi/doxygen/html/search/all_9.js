var searchData=
[
  ['italic_0',['ITALIC',['../namespaceansi.html#a39ea49abf7bffe1032b6de2328974abe',1,'ansi']]],
  ['italic_5foff_1',['ITALIC_OFF',['../namespaceansi.html#aa8d61716f86f85679112a43cd3764ed8',1,'ansi']]]
];

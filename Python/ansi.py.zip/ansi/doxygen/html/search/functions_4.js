var searchData=
[
  ['rgb_0',['RGB',['../namespaceansi.html#af6f9ad41681ea68b4f9253c4fe0447e7',1,'ansi']]]
];

var searchData=
[
  ['aux_5fport_5foff_0',['AUX_PORT_OFF',['../namespaceansi.html#adaae8fbc81d9c8288c758f545869b81e',1,'ansi']]],
  ['aux_5fport_5fon_1',['AUX_PORT_ON',['../namespaceansi.html#a99096da41487c687f2f87767360065a1',1,'ansi']]]
];

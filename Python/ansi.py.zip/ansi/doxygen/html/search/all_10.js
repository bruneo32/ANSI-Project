var searchData=
[
  ['white_0',['WHITE',['../namespaceansi.html#a0bddb525bd00a13559dc14f02df9fdaa',1,'ansi']]],
  ['white_5fhi_1',['WHITE_HI',['../namespaceansi.html#a6b7ba059ccf092496a5bcc3f656e58a3',1,'ansi']]]
];

var searchData=
[
  ['purple_0',['PURPLE',['../namespaceansi.html#a4c1dc11dbf5adf19b493796d094aadf0',1,'ansi']]],
  ['purple_5fhi_1',['PURPLE_HI',['../namespaceansi.html#a2ace314ced68458ea5d8f4697a5f3989',1,'ansi']]]
];

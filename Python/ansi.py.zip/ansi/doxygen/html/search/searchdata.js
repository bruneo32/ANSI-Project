var indexSectionsWithContent =
{
  0: "_abcdefghioprstuwy",
  1: "a",
  2: "_r",
  3: "bcehrs",
  4: "abcdefghioprsuwy",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};


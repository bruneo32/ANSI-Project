var searchData=
[
  ['green_0',['GREEN',['../namespaceansi.html#ad07f0a0cefbab9c277feff760dcaf28f',1,'ansi']]],
  ['green_5fhi_1',['GREEN_HI',['../namespaceansi.html#a29307d867b7e23aee95487142958109e',1,'ansi']]]
];

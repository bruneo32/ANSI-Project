var indexSectionsWithContent =
{
  0: "art",
  1: "ar",
  2: "a",
  3: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "defines",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Macros",
  3: "Pages"
};


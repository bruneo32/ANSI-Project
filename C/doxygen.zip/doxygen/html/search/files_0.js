var searchData=
[
  ['ansi_2eh_0',['ansi.h',['../ansi_8h.html',1,'']]]
];

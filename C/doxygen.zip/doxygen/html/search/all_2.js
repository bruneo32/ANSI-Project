var searchData=
[
  ['the_20ansi_2dproject_20for_20_3cem_3ec_2fc_2b_2b_3c_2fem_3e_0',['The ANSI-Project for &lt;em&gt;C/C++&lt;/em&gt;',['../index.html',1,'']]]
];
